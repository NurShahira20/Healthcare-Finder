<?php
include('config.php'); // Include config for database connection



// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $hospital = $_POST['hospital'];
    $user_latitude = $_POST['user_latitude'];
    $user_longitude = $_POST['user_longitude'];
    $date_time = $_POST['date_time'];
    $reason = $_POST['reason'];
    $user_agent = $_POST['user_agent'];

    // Prepare SQL query
    $query = "INSERT INTO checkin_records (user_id, name, phone, hospital, user_latitude, user_longitude, date_time, reason, user_agent) 
              VALUES ('$user_id', '$name', '$phone', '$hospital', '$user_latitude', '$user_longitude', '$date_time', '$reason', '$user_agent')";

    if (mysqli_query($conn, $query)) {
        echo "Check-in data has been successfully recorded.";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
