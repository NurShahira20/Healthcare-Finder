<?php
$servername = "localhost";
$username = "root"; // Username pangkalan data
$password = ""; // Kata laluan pangkalan data
$dbname = "checkin_db"; // Nama pangkalan data

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
